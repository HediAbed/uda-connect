create function st_snaptogrid(geometry, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
SELECT public.ST_SnapToGrid($1, 0, 0, $2, $3)
$$;

comment on function st_snaptogrid(geometry, double precision, double precision) is 'args: geomA, sizeX, sizeY - Snap all points of the input geometry to a regular grid.';

alter function st_snaptogrid(geometry, double precision, double precision) owner to ct_admin;

