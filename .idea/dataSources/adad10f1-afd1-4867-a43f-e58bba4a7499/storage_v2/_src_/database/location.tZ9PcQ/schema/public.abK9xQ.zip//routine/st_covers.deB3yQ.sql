create function st_covers(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.~) $2 AND public._ST_Covers($1,$2)
$$;

comment on function st_covers(geometry, geometry) is 'args: geomA, geomB - Returns 1 (TRUE) if no point in Geometry B is outside Geometry A';

alter function st_covers(geometry, geometry) owner to ct_admin;

