create function st_valuepercent(rast raster, nband integer, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT percent double precision) returns SETOF record
    immutable
    parallel safe
    language sql
as
$$
SELECT value, percent FROM public._ST_valuecount($1, $2, TRUE, $3, $4)
$$;

alter function st_valuepercent(raster, integer, double precision[], double precision, out double precision, out double precision) owner to ct_admin;

