create function st_force_2d(geometry) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._postgis_deprecate('ST_Force_2d', 'ST_Force2D', '2.1.0');
    SELECT public.ST_Force2D($1);
$$;

alter function st_force_2d(geometry) owner to ct_admin;

