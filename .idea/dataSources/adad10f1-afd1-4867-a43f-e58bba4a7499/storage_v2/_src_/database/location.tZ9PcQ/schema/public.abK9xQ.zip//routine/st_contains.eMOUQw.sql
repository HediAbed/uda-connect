create function st_contains(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.~) $2 AND public._ST_Contains($1,$2)
$$;

comment on function st_contains(geometry, geometry) is 'args: geomA, geomB - Returns true if and only if no points of B lie in the exterior of A, and at least one point of the interior of B lies in the interior of A.';

alter function st_contains(geometry, geometry) owner to ct_admin;

