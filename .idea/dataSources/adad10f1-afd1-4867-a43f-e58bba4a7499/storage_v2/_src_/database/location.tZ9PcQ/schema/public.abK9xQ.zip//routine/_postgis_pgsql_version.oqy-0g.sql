create function _postgis_pgsql_version() returns text
    stable
    language sql
as
$$
SELECT CASE WHEN split_part(s,'.',1)::integer > 9 THEN split_part(s,'.',1) || '0' ELSE split_part(s,'.', 1) || split_part(s,'.', 2) END AS v
	FROM substring(version(), 'PostgreSQL ([0-9\.]+)') AS s;
$$;

alter function _postgis_pgsql_version() owner to ct_admin;

