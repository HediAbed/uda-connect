create function st_asgeojson(text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_AsGeoJson(1, $1::public.geometry,15,0);
$$;

alter function st_asgeojson(text) owner to ct_admin;

